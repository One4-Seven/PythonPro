print("module1")


def xixi():
    print("xixi")
