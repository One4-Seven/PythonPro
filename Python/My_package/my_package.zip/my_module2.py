print("module2")


def haha():
    print("haha")
