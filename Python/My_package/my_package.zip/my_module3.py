print("module3")


def jiji():
    print('jiji')
